#  .-')                  .-')    .-') _     ('-.  _   .-')                      ('-. .-.   ('-.             .-. .-')   
# ( OO ).               ( OO ). (  OO) )  _(  OO)( '.( OO )_                   ( OO )  / _(  OO)            \  ( OO )  
#(_)---\_)  ,--.   ,--.(_)---\_)/     '._(,------.,--.   ,--.)         .-----. ,--. ,--.(,------.   .-----. ,--. ,--.  
#/    _ |    \  `.'  / /    _ | |'--...__)|  .---'|   `.'   |         '  .--./ |  | |  | |  .---'  '  .--./ |  .'   /  
#\  :` `.  .-')     /  \  :` `. '--.  .--'|  |    |         |         |  |('-. |   .|  | |  |      |  |('-. |      /,  
# '..`''.)(OO  \   /    '..`''.)   |  |  (|  '--. |  |'.'|  |        /_) |OO  )|       |(|  '--.  /_) |OO  )|     ' _) 
#.-._)   \ |   /  /\_  .-._)   \   |  |   |  .--' |  |   |  |        ||  |`-'| |  .-.  | |  .--'  ||  |`-'| |  .   \   
#\       / `-./  /.__) \       /   |  |   |  `---.|  |   |  |       (_'  '--'\ |  | |  | |  `---.(_'  '--'\ |  |\   \  
# `-----'    `--'       `-----'    `--'   `------'`--'   `--'          `-----' `--' `--' `------'   `-----' `--' '--'  
# CODE BY MATTHEW H. BABB ALL RIGHTS RESERVED !!!!!!!!!!!!
# Do NOT use this code without the permission of original author !!!!!!!!!!!!
                                                                                                                                
import sys                  # Import the 'system' library
import random               # Import the 'random' library which gives cool functions for randomizing numbers
from random import choice
import math                 # Import the 'math' library for more advanced math operations
import time                 # Import the 'time' library for functions of keeping track of time (ITIs, IBIs etc.)
import datetime
import os                   # Import the operating system (OS)
import glob                 # Import the glob function
import pygame               # Import Pygame to have access to all those cool functions
import Matts_Toolbox        # Import Matt's Toolbox with LRC specific functions

pygame.init()               # This initializes all pygame modules

"""READ FILES ------------------------------------------------------------------------------------------------------"""

# Read the monkey name from monkey.txt which should be located inside your program's folder
with open("monkey.txt") as f:
    monkey = f.read()

# Set Current Date
today = time.strftime('%Y-%m-%d')

"""SET UP LOCAL VARIABLES ---------------------------------------------------------------------------------------------"""

white = (255, 255, 255)                                         # This sets up colors you might need
blue = (0, 191, 255)
black = (0, 0, 0)                                               # Format is (Red, Green, Blue, Alpha)
green = (0, 200, 0)                                             # 0 is the minimum & 260 is the maximum
red = (250, 0, 0)                                               # Alpha is the transparency of a color
transparent = (0, 0, 0, 0)

"""Put your sounds here"""
sound_chime = pygame.mixer.Sound("chime.wav")                   # This sets your trial initiation sound
sound_correct = pygame.mixer.Sound("correct.wav")               # This sets your correct pellet dispensing sound
sound_incorrect = pygame.mixer.Sound("Incorrect.wav")           # This sets your incorrect sound

"""Put your Screen Parameters here"""
scrSize = (800, 600)                                            # Standard Resolution of Monkey Computers is 800 x 600. This changes for the joint computers.
scrRect = pygame.Rect((0, 0), scrSize)                          # Sets the shape of the screen to be a rectangle
fps = 60                                                        # Frames Per Second. Typically = 60. Changing this changes the cursor speed.


"""FILE MANIPULATION FUNCTIONS --------------------------------------------------------------------------------------"""

# Create an Output File
from Matts_Toolbox import writeLn

# Name the file of your Data Output
from Matts_Toolbox import makeFileName

# Get parameters from parameters.txt
from Matts_Toolbox import getParams

# Save parameters into their own file for safe keeping
from Matts_Toolbox import saveParams

"""SCREEN MANIPULATION FUNCTIONS ------------------------------------------------------------------------------------"""
from Matts_Toolbox import setScreen

from Matts_Toolbox import refresh

"""HELPER FUNCTIONS -------------------------------------------------------------------------------------------------"""
# Quit Program Function
from Matts_Toolbox import quitEscQ

# Sound Playing Function
from Matts_Toolbox import sound

# Pellet Dispensing Function
from Matts_Toolbox import pellet

# Moving the Cursor
from Matts_Toolbox import joyCount
from Matts_Toolbox import moveCursor

# Randomization Functions
from Matts_Toolbox import pseudorandomize
from Matts_Toolbox import shuffle_array

"""LIST OF TODOS ----------------------------------------------------------------------------------------------------"""


""" ICON CLASS -------------------------------------------------------------------------------------------------------"""

from Matts_Toolbox import Box
# This imports the class of Box from my tool box, which can then be used to make things on the screen
# Objects of class "Box" have certain characteristics, such as size and pixels.

# For more information on Classes, Objects, and Inheritence, you can search up "Object Oriented Programing in Python"

# Create a NEW CLASS called "ICON" which INHERITS the characteristics of class "Box"
    # You will create objects with class "Icon" to draw things on the screen that the monkeys can interact with
class Icon(Box):
    def __init__(self, PNG, position, scale):                           # To create an object you need to provide the code with the following:
                                                                            # 1. The item's image, typically a .png file
                                                                            # 2. The item's (x,y) position
                                                                            # 3. The item's size (scale)
        super(Icon, self).__init__()
        image = pygame.image.load(PNG).convert_alpha()                          # image = image you passed in arguments
        self.size = image.get_size()                                            # Get the size of the image
        self.image = pygame.transform.smoothscale(image, scale)                 # Scale the image = scale inputted
        self.rect = self.image.get_rect()                                       # Get rectangle around the image
        self.rect.center = self.position = position                             # Set rectangle and center at position
        self.mask = pygame.mask.from_surface(self.image)                        # Creates a mask object
        
    """Objects of the Icon class have this .mv2pos function"""
    """This function allows you to move the Icon anywhere on the screen"""
    def mv2pos(self, position):
        self.rect = self.image.get_rect()
        self.rect.center = self.position = position


""" TRIAL CLASS -----------------------------------------------------------------------------------------------------"""
# Next we are going to create a "Trial" Class. Think of a trial class an abstract represntation of each trial the monkey will complete
# Every trial needs all of its characteristics defined. For example, what is this trial's number? what block is this trial in? What type of trial is it? etc.

# You will ALSO need to keep track of where the monkey is WITHIN each trial. I do this by tracking the monkey's "phase".
# For example, startphase is usually the beginning of the trial where there is just a cursor and a start button
# Phase 1 might be the presentation of the target
# Phase 2 might be the presentation of the monkey's options, and so on...
# Your trials can have as many phases as you want, and the phases can differ by the type of trial the current trial is.
# So if you wanted to test how good a monkeys MTS is after completing 100 different tests, you could do it. I wouldn't... but you could...

# You can ALSO keep track of what happens inside of each trial. For example, did the monkey press the hint button?
# I call these "events".

class Trial(object):
    def __init__(self):
        super(Trial, self).__init__()
        self.train_or_test = train_or_test                  # Determine if this is a Training or a Testing Condition by pulling the value of train_or_test from parameters.txt
        self.trial_number = 0                               # Trial Number {1 - x}
        self.trial_within_block = -1                        # Trial Within the current block {0 - x}
        self.block = 1                                      # Block number {1 - x}
        self.block_length = trials_per_block                # Number of trials per block = stored in parameters.txt
        self.blocks_per_session = blocks_per_session        # Number of blocks per session = stored in parameters.txt
        self.start_time = 0

        # Keep Track of Phases




        
        # Keep Track of events that occur inside the program




        # Set up the program's stimuli files
        # This is not used in this program, but I wanted to show you an example of pulling multiple stimuli
        self.pngs = glob.glob('stimuli/*.png')              # Make a list of the .png files from the stimuli folder
        self.stimuli_idx = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]   # Make a list of all 10 stimuli indices [label 0 - 9]
        random.shuffle(self.stimuli_idx)                    # Shuffle the order of the stimuli list
        
        # Set up Trial Type Array
        #     
        #
                                                                    
        # Keep Track of Training Performance
            # This is useful if you want to advance a monkey to a different condition after they acheive 80% success
            # For example, at the end of a block you can divide num_correct by number of trials in a block to get the correct_pct
        self.num_correct = 0
        self.correct_pct = 0.00 
        self.consecutive = 0

        # Set up a blank list for the trial's stimuli; We will fill it with simuli later
        self.stimuli = []
        
        # Set up the stimuli (x,y) positions on the screen
        # If you want 4 options on the screen at once:
        self.icon_position = [(150,150), (650,450), (150, 450), (650, 150)]
        # If you want only 2 options on left & right sides:
        #self.icon_position = [(125, 300), (675, 300)]


    """Now that you have created your "Trial" class and given it all the attributes you want, it is time to give all objects of the "Trial" class access to FUNCTIONS
    Functions are a way for things to happen in the program. They can start a new trial, draw stimuli, or even make stimuli dance on the screen"""

    def new(self):
        """Start a new trial"""
        global start_time
        global SELECT
        SELECT = -1
        # TODO: Increment trial number by 1
        # TODO: Increment trial within block by 1
        # TODO: Play chime noise to alert monkey a new trial has started
        print("Trial: " + str(self.trial_number))                               # Print the information to the console
        print("Trial_within_block: " + str(self.trial_within_block))                # NOTE: This does not print the information to an excel sheet
        print("Block: " + str(self.block))                                          # We will use another function to do that
        print("Trial Type: " + str(self.trial_type))

        # TODO: Make an If Loop that says "If this is the last trial in the block, then do this:"
            # TODO: Reset trial_within_block to 0           
            # TODO: Run the function .newBlock()
            print("Block Complete!")                                            # Print "Block Complete!" to the console


        # Reset all phases to False except the Start Phase
        self.startphase = True
        self.phase1 = False
        self.phase2 = False
        self.phase3 = False

        # Reset all events to False
        self.event1 = False
        self.event2 = False
        self.event3 = False


        # TODO: Run the function .create_stimuli()
        # TODO: Move the cursor to the start position



    def newBlock(self):
        """Moves program to the next block and randomizes the trial types"""
        # TODO: Increment block by 1





        # TODO: Write an If Loop to Check if this is the last block in the session
            print("Session Complete!")                              
            # If it is, then quit!
            #


    def create_stimuli(self):
        """Create the stimuli based on the trial type"""
        """Use choice() to randomly select a stimuli within a range of indices"""
        global icon_condition # Use icon_condition from parameters.txt to counterbalance stimuli between monkeys



        # TODO: Create a list called "Icons" that is made up of a list of Objects with the "Icon" Class

        Icons = []

        # TODO: Icons[] determined which pngs are taken in, self.stimuli[] determines which stimuli can be selected for this specific trial
        
        self.stimuli = []
        # 0 = Start Button
        # 1 = Correct Button
        # 2 = Incorrect Button
          
# Basic Drawing Functions -------------------------------------------------------------------------------------------------

    def draw_start(self):
        """Draw the start button at center of the screen"""
        # TODO: Move the start button to its position
        # TODO: Draw the start button on the screen

    def draw_stimuli(self):
        """Draw the stimuli at their positions after start button is selected"""
        global icon_positions
        # TODO: Move Stimuli 1 to Position 0
        # TODO: Draw Stimuli 1 on the screen

# Time Keeping Function/Reaction Time ---------------------------------------------------------------------------------------

    def response_time(self):
        """This function tracks how long it takes for a monkey to respond after hitting the start button"""
        seconds = 0.000
        if seconds < duration:
            seconds = ((pygame.time.get_ticks() - start_time) / 1000.000)

        return seconds
        
    
# Start the trial! Now its time to start each trial and move through each phase -----------------------------------------------

    def start(self):
        global SELECT
        global timer
        global start_time

        # TODO: Draw the start button on the screen
        # TODO: Draw the cursor on the screen
        # TODO: Allow the cursor to move. Specify that it is only in the up direction

        # TODO: Write an If Loop that If the cursor collides with the start button, do the following:
            # TODO: Cause blank white screen
            # TODO: Initialize the self.start_time variable
            # TODO: Cause startphase to become False
            # TODO: Cause phase1 to become True

# Phase 1: Display Target
    def run_trial(self):
        global SELECT
        global timer
        global start_time
        global button_positions
        global duration

        # TODO: Draw the cursor on the screen. You have to do this in each phase if you want the cursor to appear
        # TODO: Allow the cursor to move in any direction

        # TODO: Move the start button off the screen
        # TODO: Make the start button tiny so it disappears

        # TODO: Run the draw_stimuli function

        # TODO: Write an If Loop for the logic of the program.
            # If the cursor collides with stimuli[1] that is the correct selection
            # TODO: Write it into the data file
            # TODO: Play the correct ding sound
            # TODO: Dispense the pellet
            # TODO: Add 1 to num_correct to track percentage
            # TODO: Fill the screen with white blank screen
            # TODO: Refresh the screen
            # TODO: Start the ITI delay
            # TODO: Begin a new trial
        
    def write(self, file, correct):
        """This function writes whatever you want to an excel file. When you call it in the program it will write one row of excel"""
        global icon_condition
        now = time.strftime('%H:%M:%S')
        data = [monkey, today, now, self.train_or_test, self.block, self.trial_number, self.trial_type[self.trial_within_block], correct]
        
        writeLn(file, data)

# ---------------------------------------------------------------------------------------------------------------------


# UPLOAD TASK PARAMETERS ----------------------------------------------------------------------------------------------
varNames = ['full_screen', 'train_or_test', 'icon_condition', 'trials_per_block', 'blocks_per_session', 'ITI',
            'duration', 'run_time', 'time_out']
params = getParams(varNames)
globals().update(params)

full_screen = params['full_screen']                     # Since your parameters are stored in a dictionary
train_or_test = params['train_or_test']                       # You can pull their value out with dictionary[key]
icon_condition = params['icon_condition']
trials_per_block = params['trials_per_block']
blocks_per_session = params['blocks_per_session']
ITI = params['ITI']
duration = params['duration']
run_time = params['run_time']
time_out = params['time_out']


# START THE CLOCK
clock = pygame.time.Clock()
start_time = (pygame.time.get_ticks() / 1000)
stop_after = run_time * 60 * 1000

# CREATE THE TASK WINDOW
screen = setScreen(full_screen)
pygame.display.set_caption("System Check")
display_icon = pygame.image.load("Monkey_Icon.png")
pygame.display.set_icon(display_icon)
screen.fill(white)

# DEFINE THE CURSOR
cursor = Box(color = red, speed = 8, circle = True)


"""CREATE THE DATA FILE-------------------------------------------------------------------------------------------"""
data_file = makeFileName('System_Check')
writeLn(data_file, ['monkey', 'date', 'time', 'training_or_testing', 'block', 'trial_number', 'trial_type', 'correct_or_incorrect'])



"""SET UP IS COMPLETE - EVERYTHING BELOW THIS IS RUNNING THE MAIN PROGRAM"""


"""MAIN GAME LOOP -------------------------------------------------------------------------------------------"""
trial = Trial()             # Initialize a new Trial

trial.new()                 # Have the newly initialized trial run .new() function to begin ;)

running = True
while running:
    quitEscQ()
    timer = (pygame.time.get_ticks() / 1000)
    if timer > run_time:
        pygame.quit()
        sys.exit()
    screen.fill(white)
    cursor.draw(screen)
    
    SELECT = cursor.collides_with_list(trial.stimuli)   # While the program is running, the variable called "SELECT"
    clock.tick(fps)                                             # is equal to the number of the stimuli in stimuli[]
    
    if trial.startphase == True:
        trial.start()
    elif trial.startphase == False:
        if trial.phase1 == True:
            trial.run_trial()


    refresh(screen)

# --------------------------------------------------------------------------------------------------------------------
